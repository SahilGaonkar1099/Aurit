# Simple-ARApp
This is an Augmented Reality app for Android Phones made in Android Studio. This app can only show you a 3d model of GEEKS FOR GEEKS text through your phone camera.
